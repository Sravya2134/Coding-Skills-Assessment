def handle_orders(product_inventory, customer_orders):
    stock_threshold = 10  # Define the stock level that triggers restocking
    for item_name, ordered_quantity in customer_orders:
        if item_name in product_inventory:
            available_stock = product_inventory[item_name]['stock']
            if available_stock >= ordered_quantity:
                product_inventory[item_name]['stock'] -= ordered_quantity  # Decrease stock
                print(f"Order completed for {item_name}. Updated stock level: {product_inventory[item_name]['stock']}")
            else:
                print(f"Error: Insufficient stock for {item_name}. Available: {available_stock}, Requested: {ordered_quantity}")
        else:
            print(f"Error: {item_name} is not found in the inventory.")

    # Check for items that need restocking
    low_stock_items = [name for name, details in product_inventory.items() if details['stock'] < stock_threshold]
    for item_name in low_stock_items:
        print(f"Alert: {item_name} needs to be restocked.")

def restock_inventory(product_inventory, restock_requests):
    for item_name, added_quantity in restock_requests:
        if item_name in product_inventory:
            product_inventory[item_name]['stock'] += added_quantity  # Increase stock level
            print(f"Restocked {added_quantity} units of {item_name}. New stock level: {product_inventory[item_name]['stock']}")
        else:
            print(f"Error: {item_name} not found for restocking.")

def collect_product_data():
    inventory = {}
    product_count = int(input("How many products do you want to enter? "))
    for _ in range(product_count):
        data = input("Enter product name and stock level (format: ProductName StockLevel): ")
        name, stock_level = data.split()
        inventory[name] = {'stock': int(stock_level)}  # Save stock level in a dictionary
    return inventory

def collect_sales_orders():
    orders = []
    order_count = int(input("How many sales orders do you have? "))
    for _ in range(order_count):
        order_data = input("Enter sales order (format: ProductName Quantity): ")
        product_name, quantity = order_data.split()
        orders.append((product_name, int(quantity)))  # Store as a tuple
    return orders

def collect_restock_data():
    restock_requests = []
    restock_count = int(input("How many products do you want to restock? "))
    for _ in range(restock_count):
        restock_data = input("Enter restock information (format: ProductName Quantity): ")
        product_name, quantity = restock_data.split()
        restock_requests.append((product_name, int(quantity)))  # Store as a tuple
    return restock_requests

# Main function to run the program
def main():
    product_inventory = collect_product_data()  # Get initial product data
    customer_orders = collect_sales_orders()  # Get sales orders from user
    handle_orders(product_inventory, customer_orders)  # Process the orders
    restock_requests = collect_restock_data()  # Get items to restock
    restock_inventory(product_inventory, restock_requests)  # Update stock levels

if __name__ == "__main__":
    main()
