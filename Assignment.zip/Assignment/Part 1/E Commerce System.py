# This class represents a User who can make orders
class User:
    def __init__(self, user_id, name, email):
        self.user_id = user_id  # Unique ID for the user
        self.name = name        # The user's name
        self.email = email      # The user's email address
        self.orders = []        # List to store the user's orders

    # Add an order to the user's list of orders
    def create_order(self, order):
        self.orders.append(order)

    # See all orders this user has made
    def view_orders(self):
        return self.orders


# This class represents a Product that can be part of an order
class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id  # Unique ID for the product
        self.name = name              # Name of the product
        self.price = price            # Price of the product


# This class represents an Order, which can have multiple products
class Order:
    STATUSES = ['pending', 'completed', 'shipped']  # Possible statuses for the order

    def __init__(self, order_id, user, products):
        self.order_id = order_id    # Unique ID for the order
        self.user = user            # The user who made the order
        self.products = products    # The list of products in the order
        self.status = 'pending'     # Orders start as 'pending'
        self.total_cost = self.calculate_total_once()  # Calculate total cost once

    # Calculate the total price of all products in the order
    def calculate_total_once(self):
        return sum(product.price for product in self.products)

    # Change the status of the order
    def update_status(self, new_status):
        if new_status in Order.STATUSES:
            self.status = new_status


# This class represents a Payment for an order
class Payment:
    def __init__(self, payment_id, order, amount):
        self.payment_id = payment_id  # Unique ID for the payment
        self.order = order            # The order this payment is for
        self.amount = amount          # How much is being paid

    # Process the payment and update the order status if the amount is correct
    def process_payment(self):
        if self.amount == self.order.total_cost:  # If the payment is exactly what is needed
            self.order.update_status('completed')  # Mark the order as completed
        else:
            raise ValueError("Incorrect payment amount")  # Raise an error if the payment is wrong


# This function allows you to interact with the system by entering details yourself
def main():
    # Gather user details from the keyboard
    user_id = int(input("Enter User ID: "))
    name = input("Enter User Name: ")
    email = input("Enter User Email: ")
    user = User(user_id, name, email)  # Create a User object

    # Add products to the order
    products = []
    num_products = int(input("How many products do you want to add? "))
    for _ in range(num_products):
        product_id = int(input("Enter Product ID: "))
        product_name = input("Enter Product Name: ")
        product_price = float(input("Enter Product Price: "))
        product = Product(product_id, product_name, product_price)  # Create a Product object
        products.append(product)  # Add the product to the list

    # Create an order for the user
    order_id = int(input("Enter Order ID: "))
    order = Order(order_id, user, products)  # Create an Order object
    user.create_order(order)  # Add the order to the user's list of orders

    # Show the user's orders
    print("\n--- User Orders ---")
    for order in user.view_orders():
        print(f"Order ID: {order.order_id}, Status: {order.status}, Total: ${order.total_cost}")

    # Get payment details
    payment_id = int(input("Enter Payment ID: "))
    payment_amount = float(input("Enter Payment Amount: "))
    payment = Payment(payment_id, order, payment_amount)  # Create a Payment object

    # Process the payment and check if it's successful
    try:
        payment.process_payment()  # Try to process the payment
        print(f"Payment processed successfully. Order status: {order.status}")
    except ValueError as e:
        print(f"Payment Error: {e}")  # Handle any payment errors


# Run the program
if __name__ == "__main__":
    main()
